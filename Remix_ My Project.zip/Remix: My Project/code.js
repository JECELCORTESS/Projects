onEvent("button5", "click", function( ) {
  setProperty("screen1", "background-color", "red");
});
