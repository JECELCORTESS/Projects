var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["star","365f432d-4f76-4caf-947c-f53c1c8972f3","d9566bf2-7513-4383-8b83-d5539abbdc80"],"propsByKey":{"star":{"name":"falling man","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":8,"looping":true,"frameDelay":12,"version":"DVMbP02bNdPLwTrwKS7IavUpeIDUW.UU","loadedFromSource":true,"saved":true,"sourceSize":{"x":90,"y":90},"rootRelativePath":"assets/star.png"},"365f432d-4f76-4caf-947c-f53c1c8972f3":{"name":"space rock","sourceUrl":null,"frameSize":{"x":59,"y":73},"frameCount":2,"looping":true,"frameDelay":12,"version":"G_484fGGhKEirP3aR2LyXVbQsvNEZV8Y","loadedFromSource":true,"saved":true,"sourceSize":{"x":118,"y":73},"rootRelativePath":"assets/365f432d-4f76-4caf-947c-f53c1c8972f3.png"},"d9566bf2-7513-4383-8b83-d5539abbdc80":{"name":"spacebattle_14_1","sourceUrl":null,"frameSize":{"x":48,"y":63},"frameCount":2,"looping":true,"frameDelay":12,"version":"CgDTVnhmSVtEVqztoeBoFYnAgzn_ryjf","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":96,"y":63},"rootRelativePath":"assets/d9566bf2-7513-4383-8b83-d5539abbdc80.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

// Variables
playSound("assets/category_space/Blackhole_SFX.mp3", true);
var score = 0;
var boy = createSprite(20, 20);
boy.setAnimation("spacebattle_14_1");
var man = createSprite(randomNumber(50, 350), randomNumber(-30, -60));
man.setAnimation("falling man");
man.velocityY = 5;
man.scale = 2;
var dude = createSprite(randomNumber(50, 350), randomNumber(-30, -60));
dude.setAnimation("falling man");
dude.velocityY = 5;
dude.scale = 2;
var shroom = createSprite(100, 100);
shroom.setAnimation("space rock");
shroom.velocityY = 3;
var mush = createSprite(300, 300);
mush.setAnimation("space rock");
mush.velocityY = 3;
// Create Sprites

function draw() {
  // draw the background
  background1();
  // update the sprites
  showScore();
  loopPlatforms();
  manloop();
  fall();
  move();
  land();
  saver();
  
  drawSprites();
}

// Functions
function background1() {
  background("blue");
  noStroke();
  fill("yellow");
  ellipse(340, 50, 60, 60);
  fill("white");
  ellipse(randomNumber(0, 400), randomNumber(0, 400), 30, 30);
  ellipse(randomNumber(0, 400), randomNumber(0, 400), 30, 30);
  if (score >= 20) {
    background2();
  }
}
function background2() {
  background("darkBlue");
  noStroke();
  fill("yellow");
  ellipse(randomNumber(0, 400), randomNumber(0, 400), 3, 3);
  ellipse(randomNumber(0, 400), randomNumber(0, 400), 3, 3);
  ellipse(340, 50, 60, 60);
  fill("darkBlue");
  ellipse(320, 30, 60, 60);
}
function showScore() {
  fill("yellow");
  textSize(20);
  text("Score",10, 10, 80, 20);
  text(score, 65, 25);
}
function loopPlatforms() {
  if (mush.y > 425) {
    mush.y = 0;
  }
  if (shroom.y > 425) {
    shroom.y = 0;
  }
}
function manloop() {
  if (man.y > 450) {
    man.y = randomNumber(-30, -60);
    man.x = randomNumber(50, 350);
  }
  if (dude.y > 450) {
    dude.y = randomNumber(-30, -60);
    dude.x = randomNumber(50, 350);
  }
}
function fall() {
  boy.velocityY = boy.velocityY + 0.25;
}
function move() {
  if (keyDown("up")) {
    boy.velocityY = -3;
  }
  if (keyDown("down")) {
    boy.velocityX = -10;
  }
  if (keyDown("left")) {
    boy.velocityX = -2;
    boy.rotationSpeed = 0;
  }
  if (keyDown("right")) {
    boy.velocityX = 2;
    boy.rotationSpeed = 0;
  }
}
function saver() {
  if (boy.isTouching(man)) {
     score = score + 1;
    man.y = randomNumber(-30, -60);
    man.x = randomNumber(50, 350);
  }
  if (boy.isTouching(dude)) {
     score = score + 1;
    dude.y = randomNumber(-30, -60);
    dude.x = randomNumber(50, 350);
  }
}
function land() {
  boy.collide(mush);
  boy.collide(shroom);
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
